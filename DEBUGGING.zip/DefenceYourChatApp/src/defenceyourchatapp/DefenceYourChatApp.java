package defenceyourchatapp;

public class DefenceYourChatApp {

    public static void main(String[] args) {
        System.out.println("\t\t[CHAT APPLICATION]\n");

        System.out.println("------------------------------------------------------");

        System.out.println("\t   A Project Presented to the\n"
                + "    Faculty College of Information Technology\n"
                + "\t  PHINMA Cagayan de Oro College\n"
                + "\t      Cagayan de Oro City\n");

        System.out.println("------------------------------------------------------");

        System.out.println("\t      In Partial Fulfillment \n"
                + "\t of the Requirements for the Degree \n"
                + "    Bachelor of Science in Information Technology");

        System.out.println("------------------------------------------------------");

        System.out.println("\t\t[LIST OF MEMBERS]\n");
        System.out.println("\t       Cordova, Aaron M."
                + "\n\t       Vergara, Justin P."
                + "\n\t    Waban, Exequil Daniel B.\n");

        System.out.println("------------------------------------------------------");

        System.out.println("\t\t   [PANELISTS]");
        System.out.println("\n\t       Riel Jun Cainglet"
                + "\n\t      Harvey Jay O. Manara\n");

        System.out.println("------------------------------------------------------");

        System.out.println("\t\t  [INSTRUCTORS]");
        System.out.println("\n\t      Lord Neil Cero Actub"
                + "\n\t     Jayson Ramirez Belmes");
        
        System.out.println("\n\n\t\t    THE END");

    }

}
